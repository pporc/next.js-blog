export interface reqPostData {
    title: string
    body: string
}

export interface resPostData extends reqPostData {
    id: number
    comments?: []
}
