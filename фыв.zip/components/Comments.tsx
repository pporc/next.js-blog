import styled from 'styled-components'

export const Comments = ({ props: comments }) => (
    <CommentWrapper>
        <Ul>
            <h3>Comments</h3>
            {comments.map((item) => (
                <li key={item.id}>
                    <BlockQuote>{item.body}</BlockQuote>
                </li>
            ))}
        </Ul>
    </CommentWrapper>
)

const CommentWrapper = styled.div`
    padding: 0 4rem;
`

const Ul = styled.ul`
    list-style: none;
    padding: 0;
`
const BlockQuote = styled.blockquote`
    border-left: 4px solid #eee;
    font-style: italic;
    margin: 0 0 2rem 0;
    padding: 0.5rem 0 0.5rem 2rem;
`
