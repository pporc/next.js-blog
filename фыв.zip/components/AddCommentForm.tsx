import { ChangeEvent, ChangeEventHandler, FormEvent, useState } from 'react'
import styled from 'styled-components'
import { Button, TextArea } from '../styles/styled'

export const AddCommentForm = ({ props: id }) => {
    const [commentValue, setCommentValue] = useState('')

    const textAreaHandler = (e: ChangeEvent<HTMLTextAreaElement>): void => {
        setCommentValue(e.target.value)
    }

    const buttonHandler = (): void => {
        console.log(commentValue)
    }

    return (
        <AddCommentWrapper>
            <H3>Add comment</H3>
            <TextArea
                name="comment"
                cols={30}
                rows={10}
                placeholder="You comment"
                onChange={textAreaHandler}
            />
            <Button onClick={buttonHandler}>send</Button>
        </AddCommentWrapper>
    )
}

const AddCommentWrapper = styled.div`
    padding: 2rem 4rem;
`
const H3 = styled.h3`
    margin: 0 0 1rem;
`
