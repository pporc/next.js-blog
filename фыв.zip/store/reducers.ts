import { ALLPOSTS, DELETEPOST, SETACTIVEPOST } from './types'

const initialState = { posts: [], activePost: null }

const rootReducer = (state = initialState, { type, payload }) => {
    switch (type) {
        case ALLPOSTS:
            return { ...state, posts: payload }
        case SETACTIVEPOST:
            return { ...state, activePost: payload }
        case DELETEPOST:
            const newArray = state.posts.filter((val) => val.id !== payload)
            return { ...state, posts: newArray }
        default:
            return state
    }
}

export default rootReducer
