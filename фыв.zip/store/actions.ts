import { ALLPOSTS, DELETEPOST, SETACTIVEPOST } from './types'
import { blogAPI } from '../services/api'
import { resPostData } from '../interfaces/postData'

export const setPostsData = (postsData: []) => ({
    type: ALLPOSTS,
    payload: postsData,
})

export const allPosts = () => async (dispatch) => {
    const data = await blogAPI.getAllPosts()

    dispatch(setPostsData(data))
}

export const SetActivePost = (activePost: resPostData) => ({
    type: SETACTIVEPOST,
    payload: activePost,
})

export const deletePost = (id: number) => ({
    type: DELETEPOST,
    payload: id,
})
