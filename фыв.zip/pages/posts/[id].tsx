import styled from 'styled-components'
import { useDispatch } from 'react-redux'
import { AddCommentForm } from '../../components/AddCommentForm'
import { Comments } from '../../components/Comments'
import { MainLayout } from '../../components/MainLayout'
import { SinglePost } from '../../components/SinglePost'
import { blogAPI } from '../../services/api'
import { SetActivePost } from '../../store/actions'

const Post = ({ post }) => {
    const dispatch = useDispatch()
    dispatch(SetActivePost(post))

    return (
        <MainLayout>
            <SinglePost props={post} />
            <Hr />
            <Comments props={post.comments} />
            <Hr />
            <AddCommentForm props={post.id} />
        </MainLayout>
    )
}

Post.getInitialProps = async (ctx) => {
    const post = await blogAPI.getPost(ctx.query.id)

    return { post }
}

export default Post

const Hr = styled.hr`
    border: 1px solid #eee;
`
