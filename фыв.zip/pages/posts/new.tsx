import { useState } from 'react'
import styled from 'styled-components'
import { MainLayout } from '../../components/MainLayout'
import { TextArea, Input, Button } from '../../styles/styled'

const NewPost = () => {
    const [title, setTitle] = useState('')
    const [body, setBody] = useState('')

    const inputHandler = (e) => {
        setTitle(e.target.value)
    }

    const areaHandler = (e) => {
        setBody(e.target.value)
    }

    const sendData = () => {
        console.log({ title, body })
    }

    return (
        <MainLayout>
            <FormWrapper>
                <Label>Post title</Label>
                <Input
                    type="text"
                    placeholder="Title"
                    onChange={inputHandler}
                />
                <Label>Post text</Label>
                <TextArea
                    name="body"
                    cols={30}
                    rows={10}
                    placeholder="Some text"
                    onChange={areaHandler}
                ></TextArea>
                <Button onClick={sendData}>Create</Button>
            </FormWrapper>
        </MainLayout>
    )
}

export default NewPost

const FormWrapper = styled.div`
    padding: 4rem;
`
const Label = styled.label`
    color: #333;
    font-size: 1rem;
    font-weight: 500;
    margin-bottom: 2px;
    letter-spacing: 0.35px;
`
