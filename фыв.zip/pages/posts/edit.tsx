import styled from 'styled-components'
import { useSelector } from 'react-redux'
import { MainLayout } from '../../components/MainLayout'
import { Input, TextArea, Button } from '../../styles/styled'

const Edit = () => {
    const post = useSelector((state) => state.activePost)

    return (
        <MainLayout>
            <FormWrapper>
                <Label>Edit title</Label>
                <Input type="text" value={post.title} onChange={(_) => _} />
                <Label>Edit text</Label>
                <TextArea
                    name="body"
                    cols={30}
                    rows={10}
                    value={post.body}
                    onChange={(_) => _}
                ></TextArea>
                <Button>Save</Button>
            </FormWrapper>
        </MainLayout>
    )
}

export default Edit

const FormWrapper = styled.div`
    padding: 4rem;
`
const Label = styled.label`
    color: #333;
    font-size: 1rem;
    font-weight: 500;
    margin-bottom: 2px;
    letter-spacing: 0.35px;
`
