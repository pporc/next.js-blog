import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { MainLayout } from '../components/MainLayout'
import { blogAPI } from '../services/api'
import { setPostsData } from '../store/actions'
import type { resPostData } from '../interfaces/postData'
import { PostCard } from '../components/PostCard'
import styled from 'styled-components'

const Home = ({ posts }) => {
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(setPostsData(posts))
    }, [dispatch])

    return (
        <MainLayout>
            <List>
                {posts.map((item: resPostData) => {
                    if (!item.body || !item.title) {
                        return null
                    } else {
                        return <PostCard props={item} key={item.id} />
                    }
                })}
            </List>
        </MainLayout>
    )
}

Home.getInitialProps = async () => {
    const posts = await blogAPI.getAllPosts()
    return { posts }
}

export default Home

const List = styled.ul`
    display: -moz-flex;
    display: -webkit-flex;
    display: -ms-flex;
    display: flex;
    -moz-flex-wrap: wrap;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -moz-align-items: -moz-stretch;
    -webkit-align-items: -webkit-stretch;
    -ms-align-items: -ms-stretch;
    align-items: stretch;
    text-align: center;
    width: 100%;
    padding: 0;
    margin: 0;
`
